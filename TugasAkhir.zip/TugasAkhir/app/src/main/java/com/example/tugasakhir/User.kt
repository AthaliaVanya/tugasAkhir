package com.example.tugasakhir

data class User(val inputuser1 : String? = null, val inputphone1 : String? = null, val inputnama1 : String? = null, val inputsandi1 : String? = null, val inputuser2 : String? = null, val inputsandi2 : String? = null, val inputphone2 : String? = null, val inputnama2 : String? = null, val inputmatkul : String? = null,
    val inputkelas : String? = null, val inputpertemuan : String? = null, val outputwaktu : String? = null, val outputlokasi : String? = null)