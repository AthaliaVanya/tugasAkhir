package com.example.tugasakhir

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class SubmitBerhasil : AppCompatActivity() {
    private lateinit var btnBeranda : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_submit_berhasil)

        btnBeranda=findViewById(R.id.btnBeranda)

        btnBeranda.setOnClickListener {
            val intentDestination = Intent(this@SubmitBerhasil, BerandaMahasiswa::class.java)
            startActivity(intentDestination)
        }
        }
    }
