package com.example.tugasakhir

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class DaftarMatkul : AppCompatActivity() {

    private lateinit var btnDaftarMatkul: Button
    private lateinit var inputmatkul: EditText
    private lateinit var database: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_daftar_matkul)

        btnDaftarMatkul = findViewById(R.id.btnDaftarMatkul)
        inputmatkul = findViewById(R.id.inputmatkul)

        // Inisialisasi Firebase Realtime Database
        database = FirebaseDatabase.getInstance().reference

        btnDaftarMatkul.setOnClickListener {
            val matkul = inputmatkul.text.toString().trim()

            if (matkul.isNotEmpty()) {
                saveMatkulToFirebase(matkul)
            } else {
                Toast.makeText(this, "Masukkan mata kuliah", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun saveMatkulToFirebase(matkul: String) {
        val matkulData = mapOf(
            "namaMataKuliah" to matkul
        )

        database.child("mataKuliah").push().setValue(matkulData)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    Toast.makeText(this, "Mata kuliah berhasil disimpan", Toast.LENGTH_SHORT).show()
                    val intentDestination = Intent(this@DaftarMatkul, BerandaPengajar::class.java)
                    startActivity(intentDestination)
                } else {
                    Toast.makeText(this, "Gagal menyimpan mata kuliah", Toast.LENGTH_SHORT).show()
                }
            }
    }
}