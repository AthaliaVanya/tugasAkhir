package com.example.tugasakhir

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class BerandaMahasiswa : AppCompatActivity() {
    private lateinit var btnlihatmatkul : Button
    private lateinit var keluar4 : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_beranda_mahasiswa)

        btnlihatmatkul = findViewById(R.id.btnlihatmatkul)
        keluar4 = findViewById(R.id.btnKeluar4)

        btnlihatmatkul.setOnClickListener {
            val intentDestination = Intent(this@BerandaMahasiswa, DaftarMatkulMahasiswa::class.java)
            startActivity(intentDestination)
        }
        keluar4.setOnClickListener {
            val intentDestination = Intent(this@BerandaMahasiswa,Login2Mahasiswa::class.java)
            startActivity(intentDestination)
        }


    }
}