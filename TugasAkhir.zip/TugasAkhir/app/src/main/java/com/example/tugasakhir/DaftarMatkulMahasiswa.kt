package com.example.tugasakhir

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class DaftarMatkulMahasiswa : AppCompatActivity() {
    private lateinit var btnmatkul1 : Button
    private lateinit var btnmatkul2 : Button
    private lateinit var btnmatkul3 : Button
    private lateinit var kembali5 : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_daftar_matkul_mahasiswa)

        btnmatkul1=findViewById(R.id.btnmatkul1)
        btnmatkul2=findViewById(R.id.btnmatkul2)
        btnmatkul3=findViewById(R.id.btnmatkul3)
        kembali5=findViewById(R.id.kembali5)

        btnmatkul1.setOnClickListener {
            val intentDestination = Intent(this@DaftarMatkulMahasiswa,MasukKelas::class.java)
            startActivity(intentDestination)
        }
        btnmatkul2.setOnClickListener {
            val intentDestination = Intent(this@DaftarMatkulMahasiswa,MasukKelas::class.java)
            startActivity(intentDestination)
        }
        btnmatkul3.setOnClickListener {
            val intentDestination = Intent(this@DaftarMatkulMahasiswa,MasukKelas::class.java)
            startActivity(intentDestination)
        }
        kembali5.setOnClickListener {
            val intentDestination = Intent(this@DaftarMatkulMahasiswa, BerandaMahasiswa::class.java)
            startActivity(intentDestination)
        }

    }
}