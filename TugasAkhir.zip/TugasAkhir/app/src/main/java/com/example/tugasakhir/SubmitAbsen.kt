package com.example.tugasakhir

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import com.example.tugasakhir.databinding.ActivitySubmitAbsenBinding
import com.google.android.gms.common.api.ResolvableApiException
import com.google.android.gms.location.*
import com.google.android.gms.tasks.CancellationTokenSource
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import java.io.IOException
import java.util.*

@Suppress("DEPRECATION")
class SubmitAbsen : AppCompatActivity() {
    private lateinit var binding: ActivitySubmitAbsenBinding
    private lateinit var fusedLocationProviderClient: FusedLocationProviderClient
    private lateinit var btnSelanjutnya: Button
    private lateinit var outputwaktu: TextClock
    private lateinit var inputkelas: EditText
    private lateinit var inputpertemuan: EditText
    private lateinit var outputlokasi: TextView
    private lateinit var database: DatabaseReference

    @RequiresApi(Build.VERSION_CODES.N)
    @SuppressLint("MissingPermission", "MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_submit_absen)

        binding = ActivitySubmitAbsenBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        outputlokasi = findViewById(R.id.outputlokasi)
        inputpertemuan = findViewById(R.id.inputpertemuan)
        inputkelas = findViewById(R.id.inputkelas)
        outputwaktu = findViewById(R.id.outputwaktu)
        btnSelanjutnya = findViewById(R.id.btnSelanjutnya)

        // Inisialisasi Firebase Realtime Database
        database = FirebaseDatabase.getInstance().reference

        btnSelanjutnya.setOnClickListener {
            saveDataToFirebase()
        }

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this)

        val locationPermissionRequest = registerForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { permissions ->

            when {
                permissions.getOrDefault(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    false
                ) || permissions.getOrDefault(
                    Manifest.permission.ACCESS_COARSE_LOCATION,
                    false
                ) -> {
                    Toast.makeText(
                        this, "Lokasi Berhasil didapatkan",
                        Toast.LENGTH_SHORT
                    ).show()

                    if (isLocationEnabled()) {
                        val result = fusedLocationProviderClient.getCurrentLocation(
                            Priority.PRIORITY_BALANCED_POWER_ACCURACY,
                            CancellationTokenSource().token
                        )
                        result.addOnCompleteListener {
                            val location =
                                "Latitude : " + it.result.latitude + "\n" +
                                        "Longitude: " + it.result.longitude

                            getAddress(it.result)
                        }
                    } else {
                        Toast.makeText(
                            this, "Izinkan Akses Lokasi",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }
        }
        binding.btnlokasi.setOnClickListener {
            locationPermissionRequest.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        }
    }

    private fun getAddress(location: Location) {
        val geocoder = Geocoder(this@SubmitAbsen, Locale.getDefault())

        try {
            val addresses = geocoder.getFromLocation(
                location.latitude, location.longitude, 1
            )
            val address = addresses!![0]
            val strAddress = """
                
                AddressLine: ${address.getAddressLine(0)}
                Admin Area: ${address.adminArea}
                Country Name: ${address.countryName}
                Feature Name: ${address.featureName}
                Locality: ${address.locality}
                
                """.trimIndent()
            binding.outputlokasi.text = strAddress
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    @SuppressLint("SuspiciousIndentation")
    private fun isLocationEnabled(): Boolean {
        val locationManager = getSystemService(LOCATION_SERVICE) as LocationManager

        try {
            return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return false
    }

    private fun createLocationRequest() {
        val locationRequest = LocationRequest.Builder(
            Priority.PRIORITY_HIGH_ACCURACY,
            10000
        ).setMinUpdateIntervalMillis(5000).build()

        val builder = LocationSettingsRequest.Builder().addLocationRequest(locationRequest)
        val client = LocationServices.getSettingsClient(this)
        val task = client.checkLocationSettings(builder.build())

        task.addOnSuccessListener {

        }
        task.addOnFailureListener { e ->
            if (e is ResolvableApiException) {
                try {
                    e.startResolutionForResult(
                        this,
                        100
                    )
                } catch (_: java.lang.Exception) {

                }
            }
        }
    }

    private fun saveDataToFirebase() {
        val kelas = inputkelas.text.toString().trim()
        val pertemuan = inputpertemuan.text.toString().trim()
        val waktu = outputwaktu.text.toString().trim()
        val lokasi = outputlokasi.text.toString().trim()

        if (kelas.isNotEmpty() && pertemuan.isNotEmpty() && waktu.isNotEmpty() && lokasi.isNotEmpty()) {
            val absenData = mapOf(
                "kelas" to kelas,
                "pertemuan" to pertemuan,
                "waktu" to waktu,
                "lokasi" to lokasi
            )

            database.child("absensi").push().setValue(absenData)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        Toast.makeText(this, "Data berhasil disimpan", Toast.LENGTH_SHORT).show()
                        val intent = Intent(this@SubmitAbsen, KameraActivity::class.java)
                        startActivity(intent)
                    } else {
                        Toast.makeText(this, "Gagal menyimpan data", Toast.LENGTH_SHORT).show()
                    }
                }
        } else {
            Toast.makeText(this, "Lengkapi semua data", Toast.LENGTH_SHORT).show()
        }
    }
}
