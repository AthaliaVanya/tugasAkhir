package com.example.tugasakhir

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import android.provider.MediaStore
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.core.content.FileProvider
import com.google.firebase.firestore.FieldValue
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import com.google.firebase.firestore.FirebaseFirestore
import java.io.ByteArrayOutputStream
import java.util.UUID

class KameraActivity : AppCompatActivity() {

    val REQUEST_CODE = 2000
    private lateinit var hasilkamera: ImageView
    private lateinit var btnKamera: Button
    private lateinit var btnKirim: Button
    private lateinit var btnSelanjutnya4 : Button
    private lateinit var storageReference: StorageReference
    private lateinit var firestore: FirebaseFirestore
    private var imageUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_kamera)

        hasilkamera = findViewById(R.id.hasilkamera)
        btnKamera = findViewById(R.id.btnKamera)
        btnKirim = findViewById(R.id.btnKirim)
        btnSelanjutnya4 = findViewById(R.id.btnSelanjutnya4)

        btnSelanjutnya4.setOnClickListener {
            val intent = Intent(this@KameraActivity, SubmitBerhasil::class.java)
            startActivity(intent)
        }

        // Inisialisasi Firebase Storage dan Firestore
        storageReference = FirebaseStorage.getInstance().reference
        firestore = FirebaseFirestore.getInstance()

        btnKamera.setOnClickListener {
            val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            startActivityForResult(cameraIntent, REQUEST_CODE)

        }

        btnKirim.setOnClickListener {
            if (imageUri != null) {
                uploadImageToFirebaseStorage(imageUri!!)
                Toast.makeText(this, "Gambar Berhasil Dikirim", Toast.LENGTH_SHORT).show()
            }
        }
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK && requestCode == REQUEST_CODE && data != null) {
            val bitmap = data.extras!!.get("data") as Bitmap
            hasilkamera.setImageBitmap(bitmap)

            // Convert bitmap to Uri
            imageUri = getImageUriFromBitmap(bitmap)
        }
    }

    private fun getImageUriFromBitmap(bitmap: Bitmap): Uri {
        val bytes = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bytes)
        val path = MediaStore.Images.Media.insertImage(contentResolver, bitmap, UUID.randomUUID().toString(), null)
        return Uri.parse(path)
    }

    private fun uploadImageToFirebaseStorage(imageUri: Uri) {
        val fileName = "images/${UUID.randomUUID()}.jpg"
        val fileRef = storageReference.child(fileName)

        fileRef.putFile(imageUri)
            .addOnSuccessListener { taskSnapshot ->
                fileRef.downloadUrl.addOnSuccessListener { uri ->
                    val downloadUrl = uri.toString()
                    saveImageUrlToFirestore(downloadUrl)
                }
            }
            .addOnFailureListener { exception ->
                // Handle unsuccessful uploads
            }
    }

    private fun saveImageUrlToFirestore(downloadUrl: String) {
        val imageInfo = hashMapOf(
            "imageUrl" to downloadUrl,
            "timestamp" to FieldValue.serverTimestamp()
        )

        firestore.collection("images")
            .add(imageInfo)
            .addOnSuccessListener { documentReference ->
                // Redirect to SubmitBerhasil activity after successful upload
                val intent = Intent(this@KameraActivity, SubmitBerhasil::class.java)
                startActivity(intent)
            }
            .addOnFailureListener { exception ->
                // Handle unsuccessful uploads
            }
    }
}
