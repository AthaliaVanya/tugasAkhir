package com.example.tugasakhir

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.tugasakhir.Absensi
import com.example.tugasakhir.adapter.KehadiranAdapter
import com.google.firebase.database.*
import com.google.firebase.firestore.FirebaseFirestore
import com.example.tugasakhir.databinding.ActivityListKehadiranBinding

class ListKehadiran : AppCompatActivity() {

    private lateinit var binding: ActivityListKehadiranBinding
    private lateinit var database: DatabaseReference
    private lateinit var firestore: FirebaseFirestore
    private lateinit var recyclerView: RecyclerView
    private lateinit var kehadiranList: MutableList<Absensi>
    private lateinit var adapter: KehadiranAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityListKehadiranBinding.inflate(layoutInflater)
        setContentView(binding.root)

        recyclerView = binding.recyclerViewKehadiran
        recyclerView.layoutManager = LinearLayoutManager(this)
        kehadiranList = mutableListOf()
        adapter = KehadiranAdapter(kehadiranList)
        recyclerView.adapter = adapter

        database = FirebaseDatabase.getInstance().getReference("absensi")
        firestore = FirebaseFirestore.getInstance()

        fetchDataFromFirebase()
    }

    private fun fetchDataFromFirebase() {
        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                kehadiranList.clear()
                if (snapshot.exists()) {
                    for (userSnapshot in snapshot.children) {
                        val absensi = userSnapshot.getValue(Absensi::class.java)
                        absensi?.let { kehadiranList.add(it) }
                    }
                    adapter.notifyDataSetChanged()
                }
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle possible errors
            }
        })

        firestore.collection("images").get()
            .addOnSuccessListener { result ->
                for (document in result) {
                    val imageUrl = document.getString("imageUrl")
                    // Assuming you have the matching data to update in absensiList
                    kehadiranList.find { it.waktu == document.getString("timestamp").toString()}
                        ?.imageUrl = imageUrl.toString()
                }
                adapter.notifyDataSetChanged()
            }
            .addOnFailureListener { exception ->
                // Handle any errors
            }
    }
}
