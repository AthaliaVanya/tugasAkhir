package com.example.tugasakhir

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.tugasakhir.databinding.ActivityRegisterMahasiswaBinding
import com.google.android.material.tabs.TabLayout.TabGravity
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.database

class RegisterMahasiswa : AppCompatActivity() {
    private lateinit var  firebaseAuth: FirebaseAuth
    private lateinit var binding: ActivityRegisterMahasiswaBinding
    private lateinit var inputnama2 : EditText
    private lateinit var inputphone2 : EditText
    private lateinit var inputsandi2 : EditText
    private lateinit var inputuser2 : EditText
    private lateinit var btnDaftarAkun2 : Button
    private lateinit var database : DatabaseReference
    private lateinit var data : FirebaseDatabase

    private fun saveUserToDB(nama : String, phone : String, email : String, sandi : String){
        val user = User(nama, phone, email, sandi)
        database.child("data register mahasiswa").child(nama).setValue(user).addOnSuccessListener {
            binding.inputnama2.text.clear()
            binding.inputphone2.text.clear()
            binding.inputsandi2.text.clear()
            binding.inputuser2.text.clear()

            Toast.makeText(this, "Berhasil", Toast.LENGTH_SHORT).show()
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterMahasiswaBinding.inflate(layoutInflater)
        setContentView(binding.root)

        firebaseAuth = Firebase.auth
        database = Firebase.database.reference
        inputnama2 = findViewById(R.id.inputnama2)
        inputphone2 = findViewById(R.id.inputphone2)
        inputsandi2 = findViewById(R.id.inputsandi2)
        inputuser2 = findViewById(R.id.inputuser2)
        btnDaftarAkun2 = findViewById(R.id.btnDaftarAkun2)

        binding.btnDaftarAkun2.setOnClickListener {
          val nama = binding.inputnama2.text.toString()
          val sandi = binding.inputsandi2.text.toString()
          val email = binding.inputuser2.text.toString()
          val phone = binding.inputphone2.text.toString()

            firebaseAuth.createUserWithEmailAndPassword(email, sandi)
                .addOnCompleteListener(this){task ->
                    if(task.isSuccessful){
                        Log.d(TAG, "createUserWithEmail:success")
                        val user = firebaseAuth.currentUser
                        saveUserToDB(nama, phone, email, sandi)
                    } else{
                        Log.w(TAG, "createUserWithEmail:failure", task.exception)
                        Toast.makeText(
                            baseContext,
                            "Gagal",
                            Toast.LENGTH_SHORT,
                        ).show()
                    }
                }


//            if (email1.isNotEmpty() && password1.isNotEmpty()) {
//                firebaseAuth.createUserWithEmailAndPassword(email1, password1)
//                    .addOnCompleteListener(this) { task ->
//                        if (task.isSuccessful) {
//                            Toast.makeText(this, "Register Berhasil", Toast.LENGTH_SHORT).show()
//                            val intent = Intent(this@RegisterMahasiswa, Login2Mahasiswa::class.java)
//                            startActivity(intent)
//                            finish()
//                        } else {
//                            Toast.makeText(this, "Register Gagal", Toast.LENGTH_SHORT).show()
//                        }
//                    }
//            } else {
//                Toast.makeText(this, "Masukkan Email dan Kata Sandi", Toast.LENGTH_SHORT).show()
//            }
        }


    }companion object{
        const val TAG = "registerActivity"
    }
}