package com.example.tugasakhir

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.tugasakhir.databinding.ActivityRegisterMahasiswaBinding
import com.example.tugasakhir.databinding.ActivityRegisterPengajarBinding
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.database

class RegisterPengajar : AppCompatActivity() {

    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var inputnama1: EditText
    private lateinit var inputphone1: EditText
    private lateinit var inputuser1: EditText
    private lateinit var inputsandi1: EditText
    private lateinit var btnDaftarAkun1: Button
    private lateinit var binding: ActivityRegisterPengajarBinding
    private lateinit var database: DatabaseReference
    private lateinit var data: FirebaseDatabase

    private fun saveUserToDB(nama: String, phone: String, email: String, sandi: String){
        val user = User(nama, phone, email, sandi)
        database.child("data register pengajar").child(nama).setValue(user).addOnSuccessListener {
            binding.inputnama1.text.clear()
            binding.inputphone1.text.clear()
            binding.inputsandi1.text.clear()
            binding.inputuser1.text.clear()

            Toast.makeText(this, "Berhasil", Toast.LENGTH_SHORT).show()

        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterPengajarBinding.inflate(layoutInflater)
        setContentView(binding.root)

        firebaseAuth = Firebase.auth
        database = Firebase.database.reference
        inputnama1 = findViewById(R.id.inputnama1)
        inputphone1 = findViewById(R.id.inputphone1)
        inputsandi1 = findViewById(R.id.inputsandi1)
        inputuser1 = findViewById(R.id.inputuser1)
        btnDaftarAkun1 = findViewById(R.id.btnDaftarAkun1)

        binding.btnDaftarAkun1.setOnClickListener {
            val nama = binding.inputnama1.text.toString()
            val phone = binding.inputphone1.text.toString()
            val email = binding.inputuser1.text.toString()
            val sandi = binding.inputsandi1.text.toString()


            firebaseAuth.createUserWithEmailAndPassword(email, sandi)
                .addOnCompleteListener(this) { task ->
                    if (task.isSuccessful) {
                        // Sign in success, update UI with the signed-in user's information
                        Log.d(TAG, "createUserWithEmail:success")
                        val user = firebaseAuth.currentUser
                        // call saveUserToDB
                        saveUserToDB(nama, phone, email, sandi)
                    } else {
                        // If sign in fails, display a message to the user.
                        Log.w(TAG, "createUserWithEmail:failure", task.exception)
                        Toast.makeText(
                            baseContext,
                            "Authentication failed.",
                            Toast.LENGTH_SHORT,
                        ).show()
                    }
                }
        }
    }

    companion object {
        const val TAG = "registerActivity"
    }
}