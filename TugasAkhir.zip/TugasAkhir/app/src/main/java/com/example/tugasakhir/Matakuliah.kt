package com.example.tugasakhir

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class Matakuliah : AppCompatActivity() {
    private lateinit var btnKelas1 : Button
    private lateinit var btnKelas2 : Button
    private lateinit var btnKelas3 : Button
    private lateinit var btnKembali : Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_matakuliah)

        btnKelas1 = findViewById(R.id.btnKelas1)
        btnKelas2 = findViewById(R.id.btnKelas2)
        btnKelas3 = findViewById(R.id.btnKelas3)
        btnKembali = findViewById(R.id.btnKembali)

        btnKelas1.setOnClickListener {
            val intentDestination = Intent(this@Matakuliah, ListKehadiran::class.java)
            startActivity(intentDestination)
        }
        btnKelas2.setOnClickListener {
            val intentDestination = Intent(this@Matakuliah, ListKehadiran::class.java)
            startActivity(intentDestination)
        }
        btnKelas3.setOnClickListener {
            val intentDestination = Intent(this@Matakuliah, ListKehadiran::class.java)
            startActivity(intentDestination)
        }
        btnKembali.setOnClickListener {
            val intentDestination = Intent(this@Matakuliah,BerandaPengajar::class.java)
            startActivity(intentDestination)
        }
        }

    }