package com.example.tugasakhir

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class BerandaPengajar : AppCompatActivity() {
    private lateinit var  btnKeluar2 : Button
    private lateinit var imageview7 : ImageView
    private lateinit var imageview6 : ImageView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_beranda_pengajar)
            btnKeluar2 = findViewById(R.id.btnKeluar2)
        imageview7 = findViewById(R.id.imageView7)
        imageview6 = findViewById(R.id.imageView6)

        btnKeluar2.setOnClickListener {
            val intentDestination = Intent(this@BerandaPengajar, Login2Pengajar::class.java)
            startActivity(intentDestination)
        }
        imageview7.setOnClickListener {
            val intenDestination = Intent(this@BerandaPengajar, DaftarMatkul::class.java)
            startActivity(intenDestination)
        }
        imageview6.setOnClickListener {
            val intenDestination = Intent(this@BerandaPengajar, Matakuliah::class.java)
            startActivity(intenDestination)
        }

        }
    }
