package com.example.tugasakhir.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.tugasakhir.Absensi
import com.example.tugasakhir.R

class KehadiranAdapter(private val absensiList: List<Absensi>) :
    RecyclerView.Adapter<KehadiranAdapter.KehadiranViewHolder>() {

    class KehadiranViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvKelas: TextView = itemView.findViewById(R.id.tvKelas)
        val tvPertemuan: TextView = itemView.findViewById(R.id.tvPertemuan)
        val tvWaktu: TextView = itemView.findViewById(R.id.tvWaktu)
        val tvLokasi: TextView = itemView.findViewById(R.id.tvLokasi)
        val imgAbsensi: ImageView = itemView.findViewById(R.id.imgAbsensi)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): KehadiranViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.activity_list_kehadiran2, parent, false)
        return KehadiranViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: KehadiranViewHolder, position: Int) {
        val absensi = absensiList[position]
        holder.tvKelas.text = absensi.kelas
        holder.tvPertemuan.text = absensi.pertemuan
        holder.tvWaktu.text = absensi.waktu
        holder.tvLokasi.text = absensi.lokasi
        Glide.with(holder.itemView.context).load(absensi.imageUrl).into(holder.imgAbsensi)
    }

    override fun getItemCount() = absensiList.size
}
