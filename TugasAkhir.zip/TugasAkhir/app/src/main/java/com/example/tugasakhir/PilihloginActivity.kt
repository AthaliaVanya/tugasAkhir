package com.example.tugasakhir

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class PilihloginActivity : AppCompatActivity() {
    private lateinit var btnPengajar: Button
    private lateinit var btnMahasiswa: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_pilihlogin)
            btnPengajar = findViewById(R.id.btnPengajar)
            btnMahasiswa = findViewById(R.id.btnMahasiswa)

        btnPengajar.setOnClickListener {
            val intentDestination = Intent(this@PilihloginActivity, LoginPengajar::class.java)
            startActivity(intentDestination)

        }
        btnMahasiswa.setOnClickListener {
            val intentDestination = Intent(this@PilihloginActivity, LoginMahasiswa::class.java)
            startActivity(intentDestination)
        }
        }
    }
