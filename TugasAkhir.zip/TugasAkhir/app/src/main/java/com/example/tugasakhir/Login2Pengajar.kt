package com.example.tugasakhir

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.tugasakhir.databinding.ActivityLogin2PengajarBinding
import com.google.firebase.auth.FirebaseAuth


class Login2Pengajar : AppCompatActivity() {
    private lateinit var btnDaftar2: Button
    private lateinit var btnMasuk2: Button
    private lateinit var btnKeluar: Button
    private lateinit var binding: ActivityLogin2PengajarBinding
    private lateinit var firebaseAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLogin2PengajarBinding.inflate(layoutInflater)
        setContentView(binding.root)

        firebaseAuth = FirebaseAuth.getInstance()

        btnDaftar2 = findViewById(R.id.btnDaftar2)
        btnMasuk2 = findViewById(R.id.btnMasuk2)
        btnKeluar = findViewById(R.id.btnKeluar)


        binding.btnMasuk2.setOnClickListener {
            val email = binding.inputuser2.text.toString()
            val password = binding.inputsandi2.text.toString()

            if (email.isNotEmpty() && password.isNotEmpty()) {
                firebaseAuth.signInWithEmailAndPassword(email, password)
                    .addOnCompleteListener(this) { task ->
                        if (task.isSuccessful) {
                            Toast.makeText(this, "Login Berhasil", Toast.LENGTH_SHORT).show()
                            val intent = Intent(this@Login2Pengajar, BerandaPengajar::class.java)
                            startActivity(intent)
                            finish()
                        } else {
                            Toast.makeText(this, "Login Gagal", Toast.LENGTH_SHORT).show()
                        }
                    }
            } else {
                Toast.makeText(this, "Masukkan Email dan Kata Sandi", Toast.LENGTH_SHORT).show()
            }
        }

        btnDaftar2.setOnClickListener {
            val intent = Intent(this@Login2Pengajar, RegisterPengajar::class.java)
            startActivity(intent)
        }
        btnKeluar.setOnClickListener {
            val intent = Intent(this@Login2Pengajar, PilihloginActivity::class.java)
            startActivity(intent)
        }
    }
}




