package com.example.tugasakhir

data class Absensi(
    val kelas: String = "",
    val pertemuan: String = "",
    val waktu: String = "",
    val lokasi: String = "",
    var imageUrl: String = ""
)


