package com.example.tugasakhir

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.tugasakhir.databinding.ActivityLogin2MahasiswaBinding
import com.google.firebase.auth.FirebaseAuth

class Login2Mahasiswa : AppCompatActivity() {
    private lateinit var btnDaftar3 : Button
    private lateinit var btnMasuk3 : Button
    private lateinit var btnKeluarmahasiswa : Button
    private lateinit var binding: ActivityLogin2MahasiswaBinding
    private lateinit var firebaseAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLogin2MahasiswaBinding.inflate(layoutInflater)
        setContentView(binding.root)

        firebaseAuth = FirebaseAuth.getInstance()
        btnDaftar3 = findViewById(R.id.btnDaftar3)
        btnMasuk3 = findViewById(R.id.btnMasuk3)
        btnKeluarmahasiswa = findViewById(R.id.btnKeluarmahasiswa)

        binding.btnMasuk3.setOnClickListener {
            val email1 = binding.inputuser4.text.toString()
            val password1 = binding.inputsandi4.text.toString()

            if (email1.isNotEmpty() && password1.isNotEmpty()) {
                firebaseAuth.signInWithEmailAndPassword(email1, password1)
                    .addOnCompleteListener(this) { task ->
                        if (task.isSuccessful) {
                            Toast.makeText(this, "Login Berhasil", Toast.LENGTH_SHORT).show()
                            val intent = Intent(this@Login2Mahasiswa, BerandaMahasiswa::class.java)
                            startActivity(intent)
                            finish()
                        } else {
                            Toast.makeText(this, "Login Gagal", Toast.LENGTH_SHORT).show()
                        }
                    }
            } else {
                Toast.makeText(this, "Masukkan Email dan Kata Sandi", Toast.LENGTH_SHORT).show()
            }
        }

        btnDaftar3.setOnClickListener {
                val intentDestination = Intent(this@Login2Mahasiswa, RegisterMahasiswa::class.java)
                startActivity(intentDestination)
            }
                btnKeluarmahasiswa.setOnClickListener {
                    val intentDestination = Intent(this@Login2Mahasiswa, PilihloginActivity::class.java)
                    startActivity(intentDestination)
                }


    }
}